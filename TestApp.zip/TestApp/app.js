    var express = require('express');
    var session = require('express-session');
    var bodyParser = require('body-parser');
    var unixTimeStamp = require('unix-timestamp');
    var path = require('path');
    var schedule = require('node-schedule');
    var wincmd = require('node-windows');
    var elevate = require('windows-elevate');
    var cmd = require('node-command-line');
    var Promise = require('bluebird');
    var app = express();



    //var loginRouter = require('./routes/login');
    var reportRouter = require('./routes/report');
    var scheduleJobs = require('./routes/scheduleJobs');
    var itemRouter = require('./routes/itemRoutes');
    var chatbotRouter = require('./routes/chatbotRoutes');


    app.use(express.static('Public'));
    var initDatabases = require('./Public/js/index');
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({
        extended: false
    }));
    app.set('views', path.join(__dirname, 'views'));
    app.set('view engine', 'ejs');

    unixTimeStamp.round = true;


    var port = 3003;

    /*function checkAuth(req, res, next) {
        if(!req.session.authenticated){
            console.log("Expired");
            res.redirect('/');
        }else{
        if (req.url != '' && (!req.session || !req.session.authenticated)) {
            var timeStamp = 1800000;
            console.log('req.session.authenticated');
            console.log("Session expiration Time  : " +req.session.cookie.maxAge);
            req.session.cookie.expires = new Date(Date.now()+timeStamp);
            req.session.cookie.maxAge = timeStamp;
            console.log("Session updated to  : " +req.session.cookie.maxAge);
            console.log(req.url);
            res.redirect(req.url);
            return;
        }
        next();
        }
    }*/

     //loginRouter(app);



        initDatabases(function (err, dbs) {
        if (err) {
            console.log('Failed to make all database connections! ');
            console.log(err);
        } else {


            //app.use(checkAuth);

                reportRouter(app,dbs);
                itemRouter(app, dbs);
                scheduleJobs(app, dbs);
                //chatbotRouter(app,dbs);

            var rule = new schedule.RecurrenceRule();
            rule.second = new schedule.Range(0, 59, 1);

            var j = schedule.scheduleJob(rule, function () {
                getScheduledJob(dbs);
            });


            function getScheduledJob(dbs) {
                dbs.execution.collection("schedule_jobs").find({
                    executionTime: {
                        $eq: unixTimeStamp.now()
                    }
                }).toArray(function (err, result) {
                    if (err) {
                        console.log(err);
                    } else {

                        if (result != "")

                        {
                            var jobString = 'D:\DB00358420\TECHM\RedwoodHQ\cli\node D:\DB00358420\TECHM\RedwoodHQ\cli\CIExecution.js --name "' + result[0].executionName + '" --user "' + result[0].userID + '" --testset "' + result[0].testSetName +
                                '" --machines "' + result[0].machineName + '" --pullLatest ' + result[0].pullLatest + ' --retryCount ' + result[0].retryCount;
                            var variablesString = "";
                            for (var i = 0; i < result[0].variableNameList.length; i++) {
                                if (i < (result[0].variableNameList.length) - 1) {
                                    variablesString = variablesString + result[0].variableNameList[i] + '=' + '"' + result[0].variableValueList[i] + '"' + ",";

                                } else
                                    variablesString = variablesString + result[0].variableNameList[i] + '=' + '"' + result[0].variableValueList[i] + '"';
                            }
                            var emailString = "";
                            if (result[0].emails.length > 0) {
                                for (var i = 0; i < result[0].emails.length; i++) {
                                    if (i < (result[0].emails.length) - 1) {
                                        emailString = emailString + result[0].emails[i] + ",";
                                    } else
                                        emailString = emailString + result[0].emails[i];
                                }
                            } else
                                emailString = result[0].emails[0];
                            jobString = jobString + ' --variables ' + variablesString + ' --emails ' + emailString + ' --tags ' + result[0].tagsList + ' --project ' + result[0].projectName + ' --ignoreScreenshots ' + result[0].ignoreScreenShot;


                            console.log(jobString);
                            //runSingleCommandWithoutWait(jobString);
                        } else {
                            console.log(" No Task Scheduled at   " + new Date() + "*****" + unixTimeStamp.now());
                        }
                    }
                });
            }

        }

    });







    app.listen(port, function () {
        console.log('Server is running on port:', port);

    });



    function runSingleCommandWithoutWait(executionString) {
        elevate.exec(executionString, function(error, stdout, stderror) {
            if (error) {
            console.error('Failed!');
            return;
            }
            console.log("Success");
        });
    }


