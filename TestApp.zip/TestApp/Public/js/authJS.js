$(document).ready(function(){
    
  $("#loginbtn").click(function(e){
    e.preventDefault();
    var usern = document.getElementById('uname').value;
    var pass = document.getElementById('pass').value;
      
    if(usern == '' || pass == ''){
      $("#authfailmsg").html("Username/Password cannot be empty");
      //alert("Username/Password cannot be empty");
    }else{
        
      $("#loginform").submit();
    }
  });
    
     

  });