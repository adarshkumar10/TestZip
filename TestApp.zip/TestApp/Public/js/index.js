    var async = require('async');
    var MongoClient = require('mongodb').MongoClient;

    //console.log("In Index.js we are printing application : "+ req.body.application);


    var AUTOMATION_URL = 'mongodb://10.13.66.82:27017/automationframework';
    var EXECUTION_URL = 'mongodb://10.13.66.202:27017/taffy';
    var AUTOMATIONOM_URL = 'mongodb://10.13.66.88:27017/automationframework';
    var TAFFYBOT_URL = 'mongodb://10.13.66.100:27017/taffybots';
    var database = {
    automation: async.apply(MongoClient.connect, AUTOMATION_URL),
    taffybot:async.apply(MongoClient.connect, TAFFYBOT_URL),
    automationOm: async.apply(MongoClient.connect, AUTOMATIONOM_URL),
    execution:async.apply(MongoClient.connect,EXECUTION_URL)
    };

    console.log('Connected to DB');
    module.exports = function (cb) {
    async.parallel(database, cb)
    };