var mongoose = require('mongoose');
var MongoClient = require('mongodb').MongoClient;
var mongoDB = "mongodb://10.13.66.239:27017/automationframework";


MongoClient.connect(mongoDB, function(err, db) {
					if (err) throw err;
					console.log('connected to database');
  
	});

	var db = mongoose.connection; 
module.exports = db.collection("executions");