var async = require('async');
var MongoClient = require('mongodb').MongoClient;

//console.log("In Index.js we are printing application : "+ req.body.application);

var opusMobileDB_URL = 'mongodb://10.13.66.88:27017/automationframework';
var EXECUTION_URL = 'mongodb://10.13.66.172:27017/taffy';
var opusMobileDB = null;
var database = {
automation: async.apply(MongoClient.connect, opusMobileDB_URL),
//execution:async.apply(MongoClient.connect,EXECUTION_URL)
};

console.log('Connected to OPUS MOBILE DB');
module.exports = function (cb) {
async.parallel(database, cb)
};