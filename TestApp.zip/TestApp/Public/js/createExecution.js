var executionListHeaders = [
    "Project Name",
    "Execution Name",
    "Execution Time",
    "TestSet Name",
    "Tags",
    "UserID",
    "Emails",
    "Retry Count",
    "Pull Latest",
    "Ignore ScreenShot",
    "Machine Name",
    " ",
    " "
];

function makeTable(container, data) {
    var table = $("<table id='executionListTable'></table>").addClass('w3-table-all w3-hoverable');
    table.css('table-layout:fixed;');
    var row = $("<tr id='heading'></tr>");
    for (var i = 0; i < executionListHeaders.length; i++) {
        row.addClass('w3-blue');
        row.append($("<th></th>").text(executionListHeaders[i]));
    }
    table.append(row);
    for (var i = 0; i < data.length; i++) {
        var row = $("<tr id='" + data[i]._id + "'></tr>");
        row.append($("<td></td>").text(data[i].projectName));
        row.append($("<td></td>").text(data[i].executionName));
        row.append($("<td></td>").text(new Date(data[i].executionTime *1000).toLocaleDateString()+" "+new Date(data[i].executionTime *1000).toLocaleTimeString()));
        row.append($("<td></td>").text(data[i].testSetName));
        row.append($("<td></td>").text(data[i].tagsList));
        row.append($("<td></td>").text(data[i].userID));
        console.log(data[i].emails.length);
        if (data[i].emails.length == 0) {
            row.append($("<td></td>").text("                                  "));
        } else {
            if (data[i].emails.length > 1)
                row.append($("<td></td>").text(data[i].emails [0]+ "..."));
        }
        row.append($("<td></td>").text(data[i].retryCount));
        row.append($("<td></td>").text(data[i].pullLatest));
        row.append($("<td></td>").text(data[i].ignoreScreenShot));
        row.append($("<td></td>").text(data[i].machineName));
        row.append($("<td></td>").append($("<button class='w3-btn btn-info updateBtn'>Update</button>")));
        row.append($("<td></td>").append($("<button class='w3-btn btn-danger delete '>Cancel</button>")));
        table.append(row);
    }

    return container.append(table);
}


(function(){


$('#datetimepicker1').datetimepicker();
	$('#sendEmails').hide();
	$('#showVariable').hide();
	
	$('#update_sendEmails').hide();
	$('#update_sendEmails').hide();
 

    $.ajax({
        url: "/getAllJobs",
        type: "POST",
        dataType: "json",
        success: function(data) {
            makeTable($('#executionTable'), data.jobs);
        }
    });
   
   
	
   $.ajax({
        url: "/getProjectName",
        type: "POST",
        dataType: "json",
        success: function(data) {
            $("#project_id").empty();
            $("#project_id").append($("<option selected='true' disabled='disabled'></option>").html("Choose a project"));
            for (var i = 0; i < data.projectName.length; i++) {
                console.log(data.projectName[i].name);
                $("#project_id").append($("<option></option>").val(data.projectName[i].name).html(data.projectName[i].name));
            }

        }
    });
	
	 $('select#project_id').change(function() {
        $.ajax({
            url: "/getTestSet",
            type: "POST",
            data: {
                project: $(this).val()
            },
            dataType: "json",
            success: function(data) {
                $("#testSet_id").empty();
                $("#testSet_id").append($("<option selected='true' disabled='disabled'></option>").html("Choose a TestSet"));
                for (var i = 0; i < data.testSetName.length; i++) {
                    console.log(data.testSetName[i].name);
                    $("#testSet_id").append($("<option></option>").val(data.testSetName[i].name).html(data.testSetName[i].name));
                }

            }
        });
		
		 $.ajax({
            url: "/getMachines",
            type: "POST",
            dataType: "json",
            success: function(data) {
                $("#machine_id").empty();
                $("#machine_id").append($("<option selected='true' disabled='disabled'></option>").html("Choose a Machine"));
                for (var i = 0; i < data.machines.length; i++) {
                    console.log(data.machines[i].description);
                    if (data.machines[i].description != "") {
                        var machineName = data.machines[i].description.split(":");
                        $("#machine_id").append($("<option></option>").val(machineName[1]).html(machineName[1]));
                    }
                }
            }
        });
		
		$.ajax({
            url: "/getUsers",
            type: "POST",
            dataType: "json",
            success: function(data) {
                $("#userID").empty();
                $("#userID").append($("<option selected='true' disabled='disabled'></option>").html("Choose a User"));
                for (var i = 0; i < data.users.length; i++) {
                    if (data.users[i].username != "admin") {
                        $("#userID").append($("<option></option>").val(data.users[i].username).html(data.users[i].name + "  (" + data.users[i].username + ")"));
                    }
                }
            }
        });

    });
	
	 $('#sendEmail').change(function() {
        var $check = $(this);
        if ($check.prop('checked')) {
            $('#sendEmails').show();
            $(this).val('True');
            $.ajax({
                url: "/getEmails",
                type: "POST",
                dataType: "json",
                success: function(data) {
                    $("#emailIDs").empty();
                    $("#emailIDs").append($("<option selected='true' disabled='disabled'></option>").html("Choose Emails"));
                    for (var i = 0; i < data.emails.length; i++) {
                        $("#emailIDs").append($("<option></option>").val(data.emails[i].email).html(data.emails[i].name));
                    }
                }
            });
        } else {
            $('#sendEmails').hide();
            $("#emailIDs").empty();
        }
    });
	
	 if ($('#ignoreScreeShotID').prop('checked')) {
        $('#ignoreScreeShotID').val('True');
    } else
        $('#ignoreScreeShotID').val('False');

    $('#variables_ID').click(function() {
        $('#showVariable').show();
    });

 $('#pullcbxID').change(function() {
        var $check = $(this);
        if ($check.prop('checked')) {
            $(this).val('True');
        } else {

            $(this).val('False');
        }
    });
	
	$('#ignoreScreeShotID').change(function() {
        var $check = $(this);
        if ($check.prop('checked')) {
            $(this).val('True');
        } else {

            $(this).val('False');
        }
    });
	
	
	 function showLatestExecutionInTable(data) {
        var row = $("<tr id='" + data.latestRecord[0]._id + "'></tr>");
        row.append($("<td></td>").text(data.latestRecord[0].projectName));
        row.append($("<td></td>").text(data.latestRecord[0].executionName));
        row.append($("<td></td>").text(new Date(data.latestRecord[0].executionTime *1000).toLocaleDateString()+" "+new Date(data.latestRecord[0].executionTime *1000).toLocaleTimeString()));
        row.append($("<td></td>").text(data.latestRecord[0].testSetName));
        row.append($("<td></td>").text(data.latestRecord[0].tagsList));
        row.append($("<td></td>").text(data.latestRecord[0].userID));
        if (data.latestRecord[0].emails.length == 0) {
            row.append($("<td></td>").text("                                  "));
        } else {
            if (data.latestRecord[0].emails.length > 1)
                row.append($("<td></td>").text(data.latestRecord[0].emails[0] + "..."));
        }
        row.append($("<td></td>").text(data.latestRecord[0].retryCount));
        row.append($("<td></td>").text(data.latestRecord[0].pullLatest));
        row.append($("<td></td>").text(data.latestRecord[0].ignoreScreenShot));
        row.append($("<td></td>").text(data.latestRecord[0].machineName));
        row.append($("<td></td>").append($("<button class='w3-btn btn-info updateBtn'>Update</button>")));
        row.append($("<td></td>").append($("<button class='w3-btn btn-danger delete '>Cancel</button>")));
        $("#heading").after(row);
    }
	
	function getLastCreatedExecution() {
        $.ajax({
            url: "/getLatestCreatedExecution",
            type: 'POST',
            contetType: "json",
            success: function(data) {
                showLatestExecutionInTable(data);
            }

        });
    }

	
	
	$('#smBtn').click(function() {
   $.confirm({
    title: 'Execution Confirmation',
    content: 'Sure You want to create Execution',
    type: 'blue',
    buttons: {   
        ok: {
            text: "ok!",
            btnClass: 'btn-primary',
            keys: ['enter'],
            action: function(){
                 $.ajax({
                    type: 'POST',
					  url: '/scheduleJob',
                    data: $('#scheduleJobForm').serialize(),
					cache: false
                }).done(function(rcvdata){
							if(rcvdata.msg.ok == 1){
						$('#scheduleJobForm').trigger('reset');
						$('#modalCreateExecution').modal('hide');
						getLastCreatedExecution();
					}
				});
            }
        },
        cancel: function(){
                $('#modalCreateExecution').modal('show');
			}
		}
	
    });
});



})();

$(document).ready(function(){

$('table').on('click','button.updateBtn',function(){
	 var rowID = $(this).parent().parent().attr('id');
		$.ajax({
				type:'POST',
				url:'/getRecordforUpdate',
				data: {id:rowID},
				success:function(data){
						console.log(data.recToUpdate);
						$('#modalUpdateExecution').modal('show');
				}
				
		});
        
});

$('table').on('click','button.delete',function(){
	 var rowID = $(this).parent().parent().attr('id');
	 $.confirm({
    title: 'Delete Confirmation',
    content: 'Sure You want to Delete Execution',
    type: 'red',
    buttons: {   
        ok: {
            text: "ok!",
            btnClass: 'btn-primary',
            keys: ['enter'],
            action: function(){
			alert(rowID);
                 $.ajax({
						type:'POST',
						url:'/deleteExecution',
						data:
								{id:rowID},
						success: function(data){
								if(data.delResponse.n == 1){
									$('table#executionListTable tr#'+rowID).remove();
								}
						}
				 });
            }
        },
        cancel: function(){
                
			}
		}
	
   }); 
        
});

});
$(document).ready(function() {

    var offset = 250;

    var duration = 300;

    $(window).scroll(function() {

        if ($(this).scrollTop() > offset) {

            $('.back-to-top').fadeIn(duration);

        } else {

            $('.back-to-top').fadeOut(duration);

        }

    });

    $('.back-to-top').click(function(event) {

        event.preventDefault();

        $('html, body').animate({
            scrollTop: 0
        }, duration);

        return false;

    })
});

function AddRow() {
    //Get the reference of the Table's TBODY element.
    var tBody = document.getElementById("tblVariable").getElementsByTagName("TBODY")[0];

    //Add Row.
    row = tBody.insertRow(-1);

    //Add Name cell.
    var cell = row.insertCell(-1);
    var variableName = document.createElement("INPUT");
    variableName.type = "text";
    variableName.type = "w3-margin w3-padding";
    variableName.placeholder = "Variable Name";
    variableName.className = "form-control";
    variableName.name = "variableNameList";
    cell.appendChild(variableName);

    //Add Country cell.
    cell = row.insertCell(-1);
    var variableValue = document.createElement("INPUT");
    variableValue.type = "text";
    variableValue.class = "w3-margin w3-padding";
    variableValue.placeholder = "Variable Value";
    variableValue.className = "form-control";
    variableValue.name = "variableValueList";
    cell.appendChild(variableValue);

    //Add Button cell.
    cell = row.insertCell(-1);
    var btnRemove = document.createElement("P");
    btnRemove.innerHTML = "<span class='glyphicon glyphicon-minus'></span>";
    btnRemove.setAttribute("onclick", "Remove(this);");
    cell.appendChild(btnRemove);
}

function Remove(button) {
    //Determine the reference of the Row using the Button.
    var row = button.parentNode.parentNode;

    if (confirm("Do you want to delete?")) {

        //Get the reference of the Table.
        var table = document.getElementById("tblVariable");

        //Delete the Table row using it's Index.
        table.deleteRow(row.rowIndex);
    }
};

function updateAddRow() {
    //Get the reference of the Table's TBODY element.
    var tBody = document.getElementById("update_tblVariable").getElementsByTagName("TBODY")[0];

    //Add Row.
    row = tBody.insertRow(-1);

    //Add Name cell.
    var cell = row.insertCell(-1);
    var variableName = document.createElement("INPUT");
    variableName.type = "text";
    variableName.type = "w3-margin w3-padding";
    variableName.placeholder = "Variable Name";
    variableName.className = "form-control";
    variableName.name = "update_variableNameList";
    cell.appendChild(variableName);

    //Add Country cell.
    cell = row.insertCell(-1);
    var variableValue = document.createElement("INPUT");
    variableValue.type = "text";
    variableValue.class = "w3-margin w3-padding";
    variableValue.placeholder = "Variable Value";
    variableValue.className = "form-control";
    variableValue.name = "update_variableValueList";
    cell.appendChild(variableValue);

    //Add Button cell.
    cell = row.insertCell(-1);
    var btnRemove = document.createElement("P");
    btnRemove.innerHTML = "<span class='glyphicon glyphicon-minus'></span>";
    btnRemove.setAttribute("onclick", "updateRemove(this);");
    cell.appendChild(btnRemove);
}

function updateRemove(button) {
    //Determine the reference of the Row using the Button.
    var row = button.parentNode.parentNode;

    if (confirm("Do you want to delete?")) {

        //Get the reference of the Table.
        var table = document.getElementById("update_tblVariable");

        //Delete the Table row using it's Index.
        table.deleteRow(row.rowIndex);
    }
};
