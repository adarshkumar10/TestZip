var myApp = angular.module("homeAngle",[])
            .controller("homeAngleController", function($scope,$http){
                var selectApplication = ['OPUS','OPUS Mobile','Business Care','Consumer Care'];
                $scope.selectApplication = selectApplication;                       
            });