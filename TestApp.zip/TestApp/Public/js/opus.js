var async = require('async');
var MongoClient = require('mongodb').MongoClient;
var express = require("express");

//console.log("In Index.js we are printing application : "+ req.body.application);
var globalConnectionStack=[];

var AUTOMATION_URL = 'mongodb://10.13.66.52:27017/automationframework';
//var EXECUTION_URL = 'mongodb://10.13.66.172:27017/taffy';

var database = {
        automation: async.apply(MongoClient.connect,AUTOMATION_URL),
        //execution:async.apply(MongoClient.connect,EXECUTION_URL)
};

console.log('Connected to Opus db');
module.exports = function (cb) {
async.parallel(database, cb)
};