    var unixTimeStamp = require('unix-timestamp');
    var ObjectID = require("mongodb").ObjectID;
    unixTimeStamp.round = true;
    module.exports = function(app, dbs) {

            app.get('/createJob', function(req, res) {
                res.render('scheduleExecution');
            });

            app.post('/scheduleJob', function(req, res) {
                var projectName = req.body.projectName;
                var executionName = req.body.executionName;
                var executionTime = req.body.executionTime;
                var timeStamp = unixTimeStamp.fromDate(req.body.executionTime);
                var testSetName = req.body.testSetName;
                var tagsList = req.body.tagsList;
                var tagString = req.body.tagsList.split(" ");
               var  tags = tagString[0];
                for (var i = 1; i < tagString.length; i++) {
                    tags = tags + "," + tagString[i];
                }
                var userID = req.body.userName;
                var emails = getUserOptionalData(req.body.emails);
                var variableNameList = getUserOptionalData(req.body.variableNameList);
                var variableValueList = getUserOptionalData(req.body.variableValueList);
                var retryCount = req.body.retryCount;
                var pullLatest = getCheckBoxValues(req.body.pullLatest);
                var ignoreScreenShot = getCheckBoxValues(req.body.ignoreScreenShot);
                var machineName = req.body.machineName;
                var scheduleJOB = {
                    projectName: projectName,
                    executionName: executionName,
                    executionTime: timeStamp,
                    testSetName: testSetName,
                    tagsList: tags,
                    userID: userID,
                    emails: emails,
                    variableNameList: variableNameList,
                    variableValueList: variableValueList,
                    retryCount: retryCount,
                    pullLatest: pullLatest,
                    ignoreScreenShot: ignoreScreenShot,
                    machineName: machineName,
                    createdAt:unixTimeStamp.now()
                };
                console.log(projectName + " " + executionName + " " + timeStamp + " " + testSetName + " " + tagsList + " " + userID + " " + emails + " " + retryCount + " " + variableNameList + " " + variableValueList + " " + pullLatest + " " + ignoreScreenShot);
                dbs.execution.collection("schedule_jobs").insertOne(scheduleJOB, function(err, result) {
                    if (err) throw err;
                    console.log("JOb inserted into Database at " + new Date() + "********" + result);
                   res.send({
                        result: result});
                });
            });


            function getUserOptionalData(data) {
                var emailArray = [];
                if (data != "") {

                    if (Array.isArray(data))
                        return data;
                    else
                            {
                        emailArray.push(data);
                    return emailArray;
                    }
                } 
            }

            function getCheckBoxValues(value) {
                if (value == "True")
                    return "True";
                else
                    return "False";
            }

            app.post('/getAllJobs', function(req, res) {

                dbs.execution.collection("schedule_jobs").find({}).toArray(function(err, result) {
                    if (err)
                        console.log(err);
                    else
                        res.send({
                            jobs: result
                        });
                });

            });

            app.post('/getProjectName', function(req, res) {
                console.log("_____________");
                dbs.automation.collection("projects").find({}).toArray(function(err, result) {
                    if (err) {
                        console.log(err);
                    } else
                        res.send({
                            projectName: result });

                });
            });

            app.post('/getTestSet', function(req, res) {
                var projectName = req.body.project;
                dbs.automation.collection("testsets").find({
                    project: projectName
                }, {}).toArray(function(err, result) {
                    if (err) {
                        console.log(err);
                    } else
                        res.send({
                            testSetName: result
                        });
                });
            });


            app.post('/getEmails', function(req, res) {
                dbs.automation.collection("users").find({}).toArray(function(err, result) {
                    if (err) {
                        console.log(err);
                    } else
                        res.send({
                            emails: result
                        });
                });
            });



            app.post('/getMachines', function(req, res) {
                dbs.automation.collection("machines").find({}).toArray(function(err, result) {
                    if (err) {
                        console.log(err);
                    } else

                        res.send({
                            machines: result
                        });
                });
            });

            app.post('/getUsers', function(req, res) {
                dbs.automation.collection("users").find({}).toArray(function(err, result) {
                    if (err) {
                        console.log(err);
                    } else
                        res.send({
                            users: result
                        });
                });
            });

            app.post('/getVariables', function(req,res){
             var projectName = req.body.projectName;
            dbs.automation.collection("variables").find({project:projectName,taskVar:true},{}).toArray(function(err, result) {
                    if (err) {
                        console.log(err);
                    } else
                        console.log(result);
                        res.send({varResult:result});
                });
            });




            app.post('/deleteExecution', function(req, res) {
                var rowID = req.body.id;
                console.log(rowID);
                dbs.execution.collection("schedule_jobs").remove({
                    _id: ObjectID(rowID)
                }, function(err, result) {
                    if (err)
                        console.log(err);
                    console.log(result.result.n + " documents deleted");
                    res.send({delResponse:result})

                });
            });
     app.post('/getLatestCreatedExecution', function(req,res){
                dbs.execution.collection("schedule_jobs").find({}).sort({createdAt:-1}).limit(1).toArray(function(err,result){
                        if(err)
                            console.log("Error Occcured while fetching the latest record at" + new Date());
                        else
                            res.send({latestRecord:result});
                });
     });

            app.post('/getRecordforUpdate', function(req, res) {
                        var rowID = req.body.id;
                        console.log(rowID);
                        dbs.execution.collection("schedule_jobs").find({_id: ObjectID(rowID)}).toArray(function(err, msg) {
                            if (err)
                                console.log(err);
                            else
                                res.send({recToUpdate:msg});
                        });
                    });

        app.post('/getExecutionByProjectName', function(req,res){
                            dbs.execution.collection("schedule_jobs").find({projectName: req.body.project}).toArray(function(err, msg) {
                            if (err)
                                console.log(err);
                            else
                                res.send({result:msg});
                        });
                    });		


        app.post('/getExecutionByStatus', function(req,res){
                            if(req.body.status == "Expired"){
                                    dbs.execution.collection("schedule_jobs").find({
                                            executionTime: { $lt: unixTimeStamp.now()},projectName:req.body.projectName 
                                    }).toArray(function(err, msg) {
                                            if (err)
                                                console.log(err);
                                            else
                                                     res.send({result:msg,status:req.body.status});
                                        });

                            }
                            else{
                                    dbs.execution.collection("schedule_jobs").find({
                                    executionTime: { $gt: unixTimeStamp.now()},projectName:req.body.projectName
                                    }).toArray(function(err, msg) {
                                    if (err)
                                        console.log(err);
                                    else
                                          res.send({result:msg,status:req.body.status});
                                });
                        }
                    });		

        app.post('/updateRecord', function(req, res) {
               var id = req.body.formID;
               console.log(id );
               var tags = '';
                var projectName = req.body.update_projectName;

                var executionName = req.body.update_executionName;
                var executionTime = req.body.executionTime;
                var timeStamp = unixTimeStamp.fromDate(req.body.update_executionTime);
                console.log(timeStamp);
                var testSetName = req.body.update_testSetName;
                var tagString = req.body.update_tagsList.split(" ");
                tags = tagString[0];
                for (var i = 1; i < tagString.length; i++) {
                    tags = tags + "," + tagString[i];
                }
                var userID = req.body.update_userName;
                var emails = getUserOptionalData(req.body.update_emails);
                var variableNameList = getUserOptionalData(req.body.update_variableNameList);
                var variableValueList = getUserOptionalData(req.body.update_variableValueList);
                var retryCount = req.body.update_retryCount;
                var pullLatest = getCheckBoxValues(req.body.update_pullLatest);
                var ignoreScreenShot = getCheckBoxValues(req.body.iupdate_gnoreScreenShot);
                var machineName = req.body.update_machineName;
                var updateExecution = {
                    projectName: projectName,
                    executionName: executionName,
                    executionTime: timeStamp,
                    testSetName: testSetName,
                    tagsList: tags,
                    userID: userID,
                    emails: emails,
                    variableNameList: variableNameList,
                    variableValueList: variableValueList,
                    retryCount: retryCount,
                    pullLatest: pullLatest,
                    ignoreScreenShot: ignoreScreenShot,
                    machineName: machineName,
                    createdAt:unixTimeStamp.now()
                };
                console.log(projectName + " " + executionName + " " + timeStamp + " " + testSetName + " " + tags + " " + userID + " " + emails + " " + retryCount + " " + variableNameList + " " + variableValueList + " " + pullLatest + " " + ignoreScreenShot);
                dbs.execution.collection("schedule_jobs").updateOne({
                                _id: ObjectID(id)
                            }, updateExecution, function(err, resUpdate) {
                                if (err) throw err;

                                else{
                                 console.log("1 document updated");
                                    res.send({msg:resUpdate,updateID:id});
                                    }
                            });
            });


                        return app;
                    };