
var ObjectId = require('mongodb').ObjectID;

module.exports = function (app,dbs){


app.get('/plan',function (req,response)
                {
                               
                                  dbs.automation.collection("actions").find({}).toArray(function(err, result)
									 {
									             if (err) throw err;
												 for(var i=0; i < result.length; i++)
													{
														 dbs.automation.collection("actions").update({
																			_id: result[i]._id
																		},
															{
																$set: {
																	temp: result[i]._id.toString()
																}
															}
																);
													}
											});
                      response.render('item');
                                         
            });

  app.get('/planning1',function (req,response)
       {
          
                     dbs.automation.collection("projects").find({}).toArray(function(err, proje)
                          {
                            if (err) throw err;
                               response.send({data:proje});
                          });
                  
        });


 app.post('/getTestcastags',function (req,res)
{
		
						 dbs.automation.collection("testcaseTags").find({"project": req.body.name}).toArray(function(err, tags)
									{
                    if (err) throw err;
										 res.send({tags:tags});
								});
         
 });

 app.post('/testcases1',function (req,response)
 {
   
            dbs.automation.collection("testcases").find({$and: [{"project": req.body.projName},{"tag": req.body.tagName}]},
           {_id:0,tag:0,status:0,collection:0,tcData:0,rowIndex:0,script:0,scriptLang:0,host:0,type:0,afterState:0,project:0,user
:0,lastModified:0}).toArray(function(err, testcases)
                 {
                   if (err) throw err;
                    response.send({testcases:testcases});
               });
        
 });


app.post('/testcases',function (req,response)
{
            
 dbs.automation.collection("testcases").aggregate([
																	 { $match : {$and: [{"project": req.body.projName},{"tag": req.body.tagName}]} },
																	{ "$unwind" : "$collection"}
																	,
																	   {
																		  $lookup:{
																			 from:"actions",
																			 localField:"collection.actionid",
																			 foreignField:"temp",
																			 as:"details"
																		  }
																	   },
                                     {
                                       $project:
                                       {
                                         "_id":1,
                                         "name":1,
                                         "description":1,
                                         "details":{"name":1,"description":1}
                                       }
                                     },
																		{ "$unwind" : "$details"},
																	   {
																		  $group:{
																			 "_id" 	: "$_id",
																			  "name": { "$first": "$name" },
																			  "description": { "$first": "$description" },
																			 "actiondetails": { "$push": "$details" },

																				},
																		  }
																	],function(err,res)
																	   {
																		if (err) throw err;
																		response.send({testcases:res});
																});
                            
});

return app;
};

